import Ent.Symptoms
import Ent.Diagnosis
import Func.DiagFinder (findDiagnos)


main :: IO ()
main = do
    let testDiagnosis = [Diagnosis "abra" [Symptoms "ali", Symptoms "aba", Symptoms "asa"] ["proced", "proced", "proced"] ["drug", "drug"], 
                        Diagnosis "cadabra" [Symptoms "nun", Symptoms "sus"] ["proced", "proced", "proced"] ["drug", "drug"], 
                        Diagnosis "ono" [Symptoms "ali", Symptoms "asa", Symptoms "st"] ["proced", "proced", "proced"] ["drug", "drug"]]

    let testSymptom = [Symptoms  "asa", Symptoms  "ali"] 

    print(show(findDiagnos testDiagnosis testSymptom))